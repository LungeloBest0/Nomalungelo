﻿using System;

// Class to store information about a student
class Student
{
    // Properties for student details
    public string StudentName { get; set; }
    public int StudentId { get; set; }
    public double[] Grades { get; set; }

    // Constructor to initialize a Student object
    public Student(string studentName, int studentId, int totalGrades)
    {
        StudentName = studentName;
        StudentId = studentId;
        Grades = new double[totalGrades];
    }

    // Method to calculate the average grade of the student
    public double CalculateAverageGrade()
    {
        if (Grades.Length == 0)
            return 0;

        double sum = 0;
        foreach (var grade in Grades)
        {
            sum += grade;
        }
        return sum / Grades.Length;
    }
}

// Class to handle user interaction and manage students
class Program
{
    static void Main()
    {
        // Get the number of students from the user
        int totalStudents = GetPositiveInteger("Enter the number of students:");

        // Create an array to store Student objects
        Student[] students = new Student[totalStudents];

        // Loop to take input for each student
        for (int i = 0; i < totalStudents; i++)
        {
            // Get the student's name
            string studentName = GetString($"Enter the name of student {i + 1}:");
            // Get the student's ID
            int studentId = GetPositiveInteger($"Enter the ID of student {i + 1}:");
            // Get the number of grades for the student
            int totalGrades = GetPositiveInteger($"Enter the number of grades for {studentName}:");

            // Initialize a new Student object
            students[i] = new Student(studentName, studentId, totalGrades);

            // Loop to take input for each grade
            for (int j = 0; j < totalGrades; j++)
            {
                students[i].Grades[j] = GetDouble($"Enter grade {j + 1} for {studentName}:");
            }
        }

        // Display the average grade for each student
        foreach (var student in students)
        {
            Console.WriteLine($"Average grade for {student.StudentName} (ID: {student.StudentId}): {student.CalculateAverageGrade():F2}");
        }

        // Wait for user to press a key before exiting
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }

    // Method to get a positive integer from the user
    static int GetPositiveInteger(string prompt)
    {
        int input;
        Console.WriteLine(prompt);
        while (!int.TryParse(Console.ReadLine(), out input) || input <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a valid positive integer.");
        }
        return input;
    }

    // Method to get a string from the user
    static string GetString(string prompt)
    {
        Console.WriteLine(prompt);
        return Console.ReadLine();
    }

    // Method to get a double from the user
    static double GetDouble(string prompt)
    {
        double input;
        Console.WriteLine(prompt);
        while (!double.TryParse(Console.ReadLine(), out input))
        {
            Console.WriteLine("Invalid input. Please enter a valid grade.");
        }
        return input;
    }
}
