import java.util.ArrayList;
import java.util.Scanner;

// Main class to handle employee management
public class Main {
    // List to store Employee objects
    public static ArrayList<Employee> employees = new ArrayList<>();
    // Scanner object to take input from the user
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Infinite loop to keep the program running until the user decides to exit
        while (true) {
            // Displaying menu options to the user
            System.out.println("1. Add Employee");
            System.out.println("2. List Employees");
            System.out.println("3. Search Employee by Name");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            // Taking the user's choice
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Switch case to handle different menu options
            switch (choice) {
                case 1:
                    addEmployee(); // Call method to add an employee
                    break;
                case 2:
                    listEmployees(); // Call method to list all employees
                    break;
                case 3:
                    searchEmployeeByName(); // Call method to search for an employee by name
                    break;
                case 4:
                    System.exit(0); // Exit the program
                default:
                    System.out.println("Invalid choice. Try again."); // Handle invalid input
            }
        }
    }

    // Method to add a new employee
    private static void addEmployee() {
        // Taking employee details from the user
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter position: ");
        String position = scanner.nextLine();
        System.out.print("Enter salary: ");
        double salary = scanner.nextDouble();

        // Creating a new Employee object with the provided details
        Employee employee = new Employee(name, id, position, salary);
        // Adding the Employee object to the list
        employees.add(employee);
        System.out.println("Employee added successfully.");
    }

    // Method to list all employees
    private static void listEmployees() {
        // Iterating over the list of employees and printing each one
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    // Method to search for an employee by name
    private static void searchEmployeeByName() {
        // Taking the name to search from the user
        System.out.print("Enter name to search: ");
        String name = scanner.nextLine();
        boolean found = false;

        // Iterating over the list of employees
        for (Employee employee : employees) {
            // Checking if the current employee's name matches the search term
            if (employee.getName().equalsIgnoreCase(name)) {
                System.out.println(employee); // Print the employee details if found
                found = true;
            }
        }
        // If no employee was found with the given name, print a message
        if (!found) {
            System.out.println("Employee not found.");
        }
    }
}
